import MapClientWrapper from "@/components/map-client-wrapper"
import CityCards from "@/components/city-cards"
import { getCitiesWeather } from "@/lib/weather"

export default async function Home() {
  const weatherData = await getCitiesWeather()

  return (
    <main className="flex min-h-screen flex-col items-center p-4 md:p-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-4 text-center">Weather in China's Most Populous Cities</h1>
      <p className="text-muted-foreground mb-6 text-center max-w-2xl">
        Real-time weather conditions in the 10 most populous cities in China. Data refreshes every 30 minutes.
      </p>
      <div className="w-full max-w-6xl h-[60vh] rounded-lg overflow-hidden border">
        <MapClientWrapper initialWeatherData={weatherData} />
      </div>
      <CityCards cities={weatherData} />
      <div className="mt-6 text-sm text-muted-foreground text-center">Data provided by WeatherAPI.com</div>
    </main>
  )
}

