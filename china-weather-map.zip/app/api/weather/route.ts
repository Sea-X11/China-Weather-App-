import { getCitiesWeather } from "@/lib/weather"
import { NextResponse } from "next/server"

export async function GET() {
  try {
    const weatherData = await getCitiesWeather()
    return NextResponse.json(weatherData)
  } catch (error) {
    console.error("Error in weather API route:", error)
    return NextResponse.json({ error: "Failed to fetch weather data" }, { status: 500 })
  }
}

