"use client"

import { useEffect, useState } from "react"
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet"
import "leaflet/dist/leaflet.css"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Thermometer, Clock, Info } from "lucide-react"
import type { CityWeather } from "@/lib/weather"
import L from "leaflet"

// Component to auto-refresh weather data
function WeatherRefresher({ onRefresh }: { onRefresh: () => void }) {
  useEffect(() => {
    const interval = setInterval(
      () => {
        onRefresh()
      },
      30 * 60 * 1000,
    ) // Refresh every 30 minutes

    return () => clearInterval(interval)
  }, [onRefresh])

  return null
}

// Component to set map view to China
function MapViewSetter() {
  const map = useMap()

  useEffect(() => {
    map.setView([35.8617, 104.1954], 4) // Center on China
  }, [map])

  return null
}

// Create a custom icon for each city based on its weather and include city name
function createWeatherIcon(iconUrl: string, cityName: string) {
  return L.divIcon({
    html: `
      <div class="city-marker">
        <img src="https:${iconUrl}" alt="Weather icon" class="weather-icon" />
        <div class="city-name">${cityName}</div>
      </div>
    `,
    className: "custom-div-icon",
    iconSize: [100, 40],
    iconAnchor: [20, 20],
    popupAnchor: [0, -20],
  })
}

export default function WeatherMap({ initialWeatherData }: { initialWeatherData: CityWeather[] }) {
  const [weatherData, setWeatherData] = useState<CityWeather[]>(initialWeatherData)

  const refreshWeatherData = async () => {
    try {
      const response = await fetch("/api/weather")
      const data = await response.json()
      setWeatherData(data)
    } catch (error) {
      console.error("Failed to refresh weather data:", error)
    }
  }

  // Add CSS for the city markers
  useEffect(() => {
    // Add CSS for the city markers
    const style = document.createElement("style")
    style.innerHTML = `
      .city-marker {
        display: flex;
        align-items: center;
      }
      .weather-icon {
        width: 40px;
        height: 40px;
      }
      .city-name {
        background-color: rgba(255, 255, 255, 0.8);
        padding: 2px 6px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 12px;
        margin-left: 4px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.2);
      }
    `
    document.head.appendChild(style)

    return () => {
      document.head.removeChild(style)
    }
  }, [])

  return (
    <>
      <MapContainer
        style={{ height: "100%", width: "100%" }}
        zoom={4}
        center={[35.8617, 104.1954]}
        scrollWheelZoom={true}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapViewSetter />
        <WeatherRefresher onRefresh={refreshWeatherData} />

        {weatherData.map((city) => (
          <Marker key={city.name} position={[city.lat, city.lon]} icon={createWeatherIcon(city.icon, city.name)}>
            <Popup maxWidth={300} minWidth={280}>
              <Card className="border-0 shadow-none">
                <CardHeader className="pb-2 pt-0 px-0">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{city.name}</CardTitle>
                    <Badge variant="outline" className="w-fit">
                      {city.population}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="px-0 py-2">
                  {/* Weather Information */}
                  <div className="mb-4 border-b pb-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <img src={`https:${city.icon}`} alt={city.condition} className="w-10 h-10" />
                        <span className="text-lg font-semibold">{city.temp_c}°C</span>
                      </div>
                      <Badge>{city.condition}</Badge>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center gap-2">
                        <Thermometer className="h-4 w-4 text-orange-500" />
                        <span>Feels: {city.feelslike_c}°C</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-blue-500" />
                        <span className="text-xs">Updated: {city.last_updated}</span>
                      </div>
                    </div>
                  </div>

                  {/* City Information */}
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Info className="h-4 w-4 text-primary" />
                      <span className="font-medium">About {city.name}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">{city.description}</p>
                  </div>
                </CardContent>
              </Card>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </>
  )
}

