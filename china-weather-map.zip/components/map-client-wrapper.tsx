"use client"

import dynamic from "next/dynamic"
import type { CityWeather } from "@/lib/weather"

// Dynamically import the WeatherMap component with SSR disabled
const WeatherMapWithNoSSR = dynamic(() => import("./weather-map"), { ssr: false })

export default function MapClientWrapper({ initialWeatherData }: { initialWeatherData: CityWeather[] }) {
  return <WeatherMapWithNoSSR initialWeatherData={initialWeatherData} />
}

