"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { CityWeather } from "@/lib/weather"

export default function CityCards({ cities }: { cities: CityWeather[] }) {
  // Sort cities by population (descending)
  const sortedCities = [...cities].sort((a, b) => {
    const popA = Number.parseFloat(a.population.split(" ")[0])
    const popB = Number.parseFloat(b.population.split(" ")[0])
    return popB - popA
  })

  return (
    <div className="w-full max-w-6xl mt-6">
      <h2 className="text-xl font-semibold mb-4">Top 10 Cities by Population</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {sortedCities.map((city, index) => (
          <Card key={city.name} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-2 pt-4 px-4">
              <CardTitle className="text-base flex justify-between items-center">
                <span>
                  {index + 1}. {city.name}
                </span>
                <img src={`https:${city.icon}`} alt={city.condition} className="w-8 h-8" />
              </CardTitle>
            </CardHeader>
            <CardContent className="px-4 pb-4 pt-0">
              <div className="flex justify-between items-center">
                <Badge variant="outline" className="font-normal">
                  {city.population}
                </Badge>
                <span className="text-sm text-muted-foreground">{city.temp_c}°C</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

