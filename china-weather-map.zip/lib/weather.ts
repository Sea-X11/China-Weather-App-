export interface CityWeather {
  name: string
  lat: number
  lon: number
  temp_c: number
  feelslike_c: number
  uv: number
  heatindex_c: number
  condition: string
  wind_kph: number
  icon: string
  last_updated: string
  population: string
  description: string
}

// Update the CITIES array to include population and description
const CITIES = [
  {
    name: "Shanghai",
    lat: 31.2304,
    lon: 121.4737,
    population: "24.9 million",
    description:
      "Shanghai is China's most populous city, located on the East China Sea at the mouth of the Yangtze River. A global financial hub, it is known for its world-class shopping, dining, and art scenes. Shanghai's iconic skyline includes The Bund and the futuristic buildings of Lujiazui.",
  },
  {
    name: "Beijing",
    lat: 39.9042,
    lon: 116.4074,
    population: "21.5 million",
    description:
      "Beijing, the capital of China, is located in the northern part of the country's eastern coast. Considered the heart of Chinese politics, culture, and history, it is home to landmarks such as the Forbidden City and the Great Wall. Beijing also hosted the 2008 Summer Olympics.",
  },
  {
    name: "Chongqing",
    lat: 29.4316,
    lon: 106.9123,
    population: "16.9 million",
    description:
      "Chongqing is located in southwestern China and is known for its mountainous terrain and spicy hot pot cuisine. As a key manufacturing and transportation hub, it plays an important role in China's economy.",
  },
  {
    name: "Tianjin",
    lat: 39.3434,
    lon: 117.3616,
    population: "13.9 million",
    description:
      "Tianjin, near Beijing, is a major port city and commercial center known for its blend of colonial and modern architecture. The city's historic concession areas and the Tianjin Eye ferris wheel attract millions of tourists annually.",
  },
  {
    name: "Guangzhou",
    lat: 23.1291,
    lon: 113.2644,
    population: "13.5 million",
    description:
      "Guangzhou is a key trade and business hub in the Pearl River Delta. The city is famous for its Cantonese cuisine and the Canton Fair. Visitors can also enjoy its ancient temples and futuristic architecture.",
  },
  {
    name: "Shenzhen",
    lat: 22.5431,
    lon: 114.0579,
    population: "12.6 million",
    description:
      "Once a small fishing village, Shenzhen has transformed into a global tech capital, often referred to as China's Silicon Valley. It is home to companies like Huawei and Tencent and is known for its vibrant nightlife and contemporary art scene.",
  },
  {
    name: "Chengdu",
    lat: 30.5723,
    lon: 104.0665,
    population: "11.5 million",
    description:
      "Chengdu is famous for its spicy Sichuan cuisine and giant pandas. The city also offers a relaxed lifestyle, attracting both tourists and residents.",
  },
  {
    name: "Nanjing",
    lat: 32.0603,
    lon: 118.7969,
    population: "9.3 million",
    description:
      "A historic capital of China, Nanjing is rich in cultural and historical landmarks, including the Ming Tombs and Sun Yat-sen Mausoleum. It is also known for its vibrant economy and thriving arts scene.",
  },
  {
    name: "Wuhan",
    lat: 30.5928,
    lon: 114.3055,
    population: "8.6 million",
    description:
      "Located along the Yangtze River, Wuhan is a major transportation and education hub. While it gained recent notoriety as the place where COVID-19 was first discovered, Wuhan is also known for its cherry blossoms and bustling street food scene.",
  },
  {
    name: "Xi'an",
    lat: 34.3416,
    lon: 108.9398,
    population: "8.5 million",
    description:
      "Xi'an, the starting point of the Silk Road, is best known for the Terracotta Army. The ancient city also has a growing tech sector, preserved city walls, and cultural festivals.",
  },
]

// Update the getCitiesWeather function to include icon and last_updated
export async function getCitiesWeather(): Promise<CityWeather[]> {
  try {
    // In a real application, you would use your WeatherAPI key here
    const apiKey = process.env.WEATHER_API_KEY

    if (!apiKey) {
      console.warn("WeatherAPI key not found, using mock data")
      return getMockWeatherData()
    }

    const weatherPromises = CITIES.map(async (city) => {
      const response = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${city.lat},${city.lon}&aqi=no`,
        { next: { revalidate: 1800 } }, // Cache for 30 minutes
      )

      if (!response.ok) {
        throw new Error(`Failed to fetch weather for ${city.name}`)
      }

      const data = await response.json()

      return {
        name: city.name,
        lat: city.lat,
        lon: city.lon,
        temp_c: data.current.temp_c,
        feelslike_c: data.current.feelslike_c,
        uv: data.current.uv,
        heatindex_c: data.current.feelslike_c, // Using feelslike as heatindex
        condition: data.current.condition.text,
        wind_kph: data.current.wind_kph,
        icon: data.current.condition.icon,
        last_updated: data.current.last_updated,
        population: city.population,
        description: city.description,
      }
    })

    return await Promise.all(weatherPromises)
  } catch (error) {
    console.error("Error fetching weather data:", error)
    return getMockWeatherData()
  }
}

// Update the mock data function to include the new fields
function getMockWeatherData(): CityWeather[] {
  const conditions = [
    { text: "Sunny", icon: "//cdn.weatherapi.com/weather/64x64/day/113.png" },
    { text: "Partly cloudy", icon: "//cdn.weatherapi.com/weather/64x64/day/116.png" },
    { text: "Cloudy", icon: "//cdn.weatherapi.com/weather/64x64/day/119.png" },
    { text: "Light rain", icon: "//cdn.weatherapi.com/weather/64x64/day/296.png" },
    { text: "Overcast", icon: "//cdn.weatherapi.com/weather/64x64/day/122.png" },
  ]

  return CITIES.map((city) => {
    const conditionIndex = Math.floor(Math.random() * 5)
    return {
      name: city.name,
      lat: city.lat,
      lon: city.lon,
      temp_c: Math.floor(Math.random() * 15) + 15, // Random temp between 15-30°C
      feelslike_c: Math.floor(Math.random() * 15) + 15,
      uv: Math.floor(Math.random() * 10) + 1,
      heatindex_c: Math.floor(Math.random() * 15) + 15,
      condition: conditions[conditionIndex].text,
      wind_kph: Math.floor(Math.random() * 20) + 5,
      icon: conditions[conditionIndex].icon,
      last_updated: new Date().toISOString().replace("T", " ").substring(0, 16),
      population: city.population,
      description: city.description,
    }
  })
}

